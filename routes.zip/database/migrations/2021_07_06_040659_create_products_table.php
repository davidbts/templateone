<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_unicode_ci';
            $table->integer('id')->autoIncrement();
            $table->integer('user_id');
            $table->integer('size_id');
            $table->string('color_id', 255);
            $table->integer('status_id');
            $table->integer('category_id');
            $table->integer('subcategory_id');
            $table->integer('element_id');
            $table->string('brand_id', 255);
            $table->string('name', 255);
            $table->text('description');
            $table->integer('price');
            $table->integer('original_price');
            $table->integer('discount');
            $table->integer('existence');
            $table->dateTime('created_at');
            $table->dateTime('updated_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
