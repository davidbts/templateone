<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_unicode_ci';
            $table->integer('id')->autoIncrement();
            $table->string('role', 20)->nullable();
            $table->string('name', 255);
            $table->string('lastname', 255)->nullable();
            $table->string('nickname', 255)->nullable();
            $table->string('email', 255)->unique();
            $table->string('password', 255)->nullable();
            $table->boolean('registered');
            $table->dateTime('last_connection');
            $table->string('image', 255)->nullable();
            $table->date('dateOfBirth')->nullable();
            $table->bigInteger('phoneNumber')->nullable();
            $table->dateTime('email_verified_at')->nullable();
            $table->dateTime('created_at');
            $table->dateTime('updated_at');
            $table->rememberToken();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
