<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDeliveriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('deliveries', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_unicode_ci';
            $table->integer('id')->autoIncrement();
            $table->integer('user_id');
            $table->string('name', 255);
            $table->string('lastname', 255);
            $table->string('street', 255);
            $table->string('outdoorNumber', 255);
            $table->string('interiorNumber', 255)->nullable();
            $table->string('postalCode', 255);
            $table->string('state', 255);
            $table->string('city', 255);
            $table->string('municipality', 255);
            $table->string('suburb', 255);
            $table->string('references', 255);
            $table->bigInteger('phoneNumber');
            $table->string('email', 255);
            $table->dateTime('created_at');
            $table->dateTime('updated_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
