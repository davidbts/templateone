<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateDeliveriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('subcomments');
        Schema::dropIfExists('purchases');
        Schema::dropIfExists('brand_categories');
        Schema::dropIfExists('password_resets');
        Schema::dropIfExists('images');
        Schema::dropIfExists('social_profiles');
        Schema::dropIfExists('likes');
        Schema::dropIfExists('comments');
        Schema::dropIfExists('products');
        Schema::dropIfExists('sizes');
        Schema::dropIfExists('statuses');
        Schema::dropIfExists('brands');
        Schema::dropIfExists('colors');
        Schema::dropIfExists('elements');
        Schema::dropIfExists('subcategories');
        Schema::dropIfExists('categories');
        Schema::dropIfExists('users');
        Schema::dropIfExists('deliveries');
    }
}
