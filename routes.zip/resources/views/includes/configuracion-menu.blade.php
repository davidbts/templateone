<div class="configuracion-menu">
    <div class="config-item-menu">
        <h4 class="config-item-titulo parrafo1">Personal</h4>
        <a href="{{ route('user.account') }}" class="config-item-link parrafo1">Sobre Mi</a>
        <a href="{{ route('user.sellMore') }}" class="config-item-link parrafo1">Mi Banco</a>
    </div>
    <div class="config-item-menu">
        <h4 class="config-item-titulo parrafo1">UPTON4EVER</h4>
        <a href="{{ route('user.delivery') }}" class="config-item-link parrafo1">Usuario</a>
        <a href="{{ route('user.password') }}" class="config-item-link parrafo1">Contraseña</a>
        <a href="{{ route('user.notifications') }}" class="config-item-link parrafo1">Notificaciones</a>
        <!-- <a href="{{ route('user.sellMore') }}" class="config-item-link parrafo1">Vender Más</a> -->
    </div>
    <!-- <div class="config-item-menu">
        <h4 class="config-item-titulo parrafo1">Comunidad</h4>
        <a href="#" class="config-item-link parrafo1">Personalización</a>
        <a href="" class="config-item-link parrafo1">Modo Vacaciones</a>
    </div> -->
</div>
