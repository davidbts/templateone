<div class="modal-recuperar">
        <i class="fa fa-times cerrar-recuperar"></i>
        <img class="logo-modal" src=" {{ asset('img/upton-logo.jpg') }} " alt="">
        <p class="parrafo1 parrafo1-login">Recupera tu contraseña</p>
        <form action="" class="form-recuperar">
          <div>
            <label for="">Correo Electronico:</label>
            <input type="email" name="" id="">
          </div>

          <button class="btn btn-enviar">Enviar</button>
        </form>
        
      </div>