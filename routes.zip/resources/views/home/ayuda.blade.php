@extends('layouts.app')

@section('content')
<div class="contenedor-ayuda">

    <div class="ayuda-titulo">
        <h2 class="titulo2">AYUDA</h2>
    </div>

    <div class="ayuda-info">


    </div>

</div>
@endsection